import 'package:flutter/material.dart';
import 'package:flutter_localizations/flutter_localizations.dart';
import 'package:provider/provider.dart';

import 'screens/home.dart';
import 'services/notify.dart';
import 'store.dart';
import 'theme.dart';

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();
  final app = AppState();
  await app.load();
  try {
    await Notify.init();
    await Notify.refreshDaily(app);
  } catch (_) {}
  runApp(ChangeNotifierProvider.value(value: app, child: const WaraqaApp()));
}

class WaraqaApp extends StatelessWidget {
  const WaraqaApp({super.key});

  @override
  Widget build(BuildContext context) {
    final mode = context.select<AppState, String>((a) => a.settings.theme);
    return MaterialApp(
      title: 'ورقة',
      debugShowCheckedModeBanner: false,
      theme: buildTheme(Brightness.light),
      darkTheme: buildTheme(Brightness.dark),
      themeMode: mode == 'light'
          ? ThemeMode.light
          : mode == 'dark'
              ? ThemeMode.dark
              : ThemeMode.system,
      locale: const Locale('ar'),
      supportedLocales: const [Locale('ar'), Locale('en')],
      localizationsDelegates: const [
        GlobalMaterialLocalizations.delegate,
        GlobalWidgetsLocalizations.delegate,
        GlobalCupertinoLocalizations.delegate,
      ],
      home: const HomeShell(),
    );
  }
}
