import 'dart:math' as math;

import 'package:flutter/material.dart';

import '../theme.dart';

/// نبتة تنمو على مراحل (growth من 0 إلى 1) وتذبل عند الإلغاء.
class PlantView extends StatefulWidget {
  const PlantView({
    super.key,
    required this.growth,
    this.wilt = false,
    this.height = 240,
    this.animate = true,
  });
  final double growth;
  final bool wilt;
  final double height;
  final bool animate;

  @override
  State<PlantView> createState() => _PlantViewState();
}

class _PlantViewState extends State<PlantView>
    with SingleTickerProviderStateMixin {
  AnimationController? _c;

  @override
  void initState() {
    super.initState();
    if (widget.animate) {
      _c = AnimationController(vsync: this, duration: const Duration(seconds: 3))
        ..repeat(reverse: true);
    }
  }

  @override
  void dispose() {
    _c?.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final line = Pal.of(context).line;
    final Animation<double> anim = _c ?? const AlwaysStoppedAnimation<double>(0.5);
    return SizedBox(
      height: widget.height,
      width: widget.height * 200 / 240,
      child: CustomPaint(
        painter: _PlantPainter(widget.growth, widget.wilt, anim, line),
      ),
    );
  }
}

class _PlantPainter extends CustomPainter {
  _PlantPainter(this.growth, this.wilt, this.sway, this.line)
      : super(repaint: sway);
  final double growth;
  final bool wilt;
  final Animation<double> sway;
  final Color line;

  static const potColor = Color(0xFFC8A27A);
  static const soil = Color(0xFF6B4A33);
  static const leafGreen = Color(0xFF7BA05B);
  static const leafDry = Color(0xFFB59A62);

  Paint _fill(Color c) => Paint()..color = c;
  Paint _stroke(double w) => Paint()
    ..color = line
    ..style = PaintingStyle.stroke
    ..strokeWidth = w
    ..strokeJoin = StrokeJoin.round
    ..strokeCap = StrokeCap.round;

  void _shape(Canvas c, Path p, Color fill) {
    c.drawPath(p, _fill(fill));
    c.drawPath(p, _stroke(3));
  }

  Offset _bez(Offset a, Offset c, Offset b, double t) {
    final u = 1 - t;
    return Offset(u * u * a.dx + 2 * u * t * c.dx + t * t * b.dx,
        u * u * a.dy + 2 * u * t * c.dy + t * t * b.dy);
  }

  void _leaf(Canvas c, Offset p, double dir, double s, Color col) {
    if (s < 1) return;
    c.save();
    c.translate(p.dx, p.dy);
    if (wilt) c.rotate(dir * 0.9);
    final path = Path()
      ..moveTo(0, 0)
      ..quadraticBezierTo(dir * s * 0.6, -s * 0.9, dir * s * 1.5, -s * 0.2)
      ..quadraticBezierTo(dir * s * 0.7, s * 0.35, 0, 0)
      ..close();
    _shape(c, path, col);
    c.drawLine(Offset.zero, Offset(dir * s * 1.0, -s * 0.2), _stroke(1.6));
    c.restore();
  }

  @override
  void paint(Canvas canvas, Size size) {
    canvas.scale(size.width / 200, size.height / 240);
    final g = growth.clamp(0.0, 1.0).toDouble();

    // الأصيص
    final pot = Path()
      ..moveTo(66, 186)
      ..lineTo(134, 186)
      ..lineTo(124, 234)
      ..lineTo(76, 234)
      ..close();
    _shape(canvas, pot, potColor);
    final rim = RRect.fromLTRBR(58, 170, 142, 190, const Radius.circular(8));
    canvas.drawRRect(rim, _fill(potColor));
    canvas.drawRRect(rim, _stroke(3));
    final soilRect = RRect.fromLTRBR(66, 172, 134, 182, const Radius.circular(5));
    canvas.drawRRect(soilRect, _fill(soil));

    // الساق
    final sw = (sway.value * 2 - 1);
    final stemH = g * 128;
    const base = Offset(100, 176);
    final droop = wilt ? 34 * g : 0.0;
    final top = Offset(100 + sw * 7 * g + droop, base.dy - stemH + (wilt ? stemH * 0.28 : 0));
    final ctrl = Offset(100 + sw * 3 - (wilt ? 8 : 0), base.dy - stemH * 0.55);

    if (stemH < 8) {
      // برعم صغير
      final c = wilt ? leafDry : leafGreen;
      canvas.save();
      canvas.translate(100, 176);
      for (final d in [-1.0, 1.0]) {
        final p = Path()
          ..moveTo(0, 0)
          ..quadraticBezierTo(d * 8, -14, d * 16, -10)
          ..quadraticBezierTo(d * 8, 0, 0, 0)
          ..close();
        _shape(canvas, p, c);
      }
      canvas.restore();
      return;
    }

    final stem = Path()
      ..moveTo(base.dx, base.dy)
      ..quadraticBezierTo(ctrl.dx, ctrl.dy, top.dx, top.dy);
    canvas.drawPath(stem, _stroke(12));
    canvas.drawPath(
        stem,
        Paint()
          ..color = wilt ? leafDry : leafGreen
          ..style = PaintingStyle.stroke
          ..strokeWidth = 7
          ..strokeCap = StrokeCap.round);

    // الأوراق
    const ts = [0.3, 0.5, 0.68, 0.85];
    for (var i = 0; i < ts.length; i++) {
      final start = 0.1 + i * 0.2;
      final k = ((g - start) / 0.2).clamp(0.0, 1.0).toDouble();
      final s = k * (24 - i * 2.5);
      final p = _bez(base, ctrl, top, ts[i]);
      _leaf(canvas, p, i.isEven ? -1 : 1, s, wilt ? leafDry : leafGreen);
    }

    // الزهرة
    if (g > 0.94 && !wilt) {
      final f = ((g - 0.94) / 0.06).clamp(0.0, 1.0).toDouble();
      for (var i = 0; i < 6; i++) {
        final a = i * math.pi / 3;
        final c = top + Offset(math.cos(a), math.sin(a)) * (13 * f);
        canvas.drawCircle(c, 9 * f, _fill(const Color(0xFFFFF1D6)));
        canvas.drawCircle(c, 9 * f, _stroke(2.5));
      }
      canvas.drawCircle(top, 8 * f, _fill(const Color(0xFFE9B422)));
      canvas.drawCircle(top, 8 * f, _stroke(2.5));
    }
  }

  @override
  bool shouldRepaint(covariant _PlantPainter old) =>
      old.growth != growth || old.wilt != wilt || old.line != line;
}
