import 'dart:convert';
import 'dart:typed_data';

import 'package:audioplayers/audioplayers.dart';
import 'package:flutter_tts/flutter_tts.dart';
import 'package:http/http.dart' as http;

import '../models.dart';

bool hasArabic(String s) => RegExp(r'[؀-ۿ]').hasMatch(s);

/// محركات الصوت: صوت الجهاز، Google (عصبي عبر الإنترنت)، OpenAI TTS.
class Tts {
  Tts._();
  static final Tts i = Tts._();

  final FlutterTts _dev = FlutterTts();
  final AudioPlayer _player = AudioPlayer();

  Future<void> stop() async {
    try {
      await _dev.stop();
      await _player.stop();
    } catch (_) {}
  }

  Future<void> speak(String text, Settings s, {String? lang}) async {
    final t = text.trim();
    if (t.isEmpty) return;
    final code = lang ?? (hasArabic(t) ? 'ar-SA' : s.ttsLang);
    await stop();
    try {
      if (s.ttsEngine == 'openai' && s.apiKey.trim().isNotEmpty) {
        await _openai(t, s);
        return;
      }
      if (s.ttsEngine == 'google') {
        await _google(t, code);
        return;
      }
    } catch (_) {
      // نكمل بصوت الجهاز كاحتياط
    }
    await _device(t, code, s.ttsRate);
  }

  Future<void> _device(String t, String lang, double rate) async {
    await _dev.setLanguage(lang);
    await _dev.setSpeechRate(rate);
    await _dev.setPitch(1.0);
    await _dev.speak(t);
  }

  Future<void> _google(String t, String lang) async {
    final tl = lang.split('-').first;
    final q = t.length > 190 ? t.substring(0, 190) : t;
    final url = Uri.parse(
        'https://translate.google.com/translate_tts?ie=UTF-8&client=tw-ob&tl=$tl&q=${Uri.encodeComponent(q)}');
    final r = await http
        .get(url, headers: {'User-Agent': 'Mozilla/5.0'})
        .timeout(const Duration(seconds: 15));
    if (r.statusCode != 200 || r.bodyBytes.isEmpty) {
      throw Exception('google tts ${r.statusCode}');
    }
    await _player.play(BytesSource(Uint8List.fromList(r.bodyBytes)));
  }

  Future<void> _openai(String t, Settings s) async {
    final r = await http
        .post(
          Uri.parse('https://api.openai.com/v1/audio/speech'),
          headers: {
            'Authorization': 'Bearer ${s.apiKey.trim()}',
            'Content-Type': 'application/json',
          },
          body: jsonEncode({
            'model': 'gpt-4o-mini-tts',
            'voice': 'nova',
            'input': t,
            'response_format': 'mp3',
          }),
        )
        .timeout(const Duration(seconds: 30));
    if (r.statusCode != 200) throw Exception('openai tts ${r.statusCode}');
    await _player.play(BytesSource(Uint8List.fromList(r.bodyBytes)));
  }
}
