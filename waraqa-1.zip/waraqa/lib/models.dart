class Flashcard {
  Flashcard({
    required this.id,
    required this.front,
    required this.back,
    this.image,
    this.box = 0,
    this.due = 0,
    int? created,
  }) : created = created ?? DateTime.now().millisecondsSinceEpoch;

  final String id;
  String front;
  String back;
  String? image;
  int box;
  int due;
  final int created;

  Map<String, dynamic> toJson() => {
        'id': id,
        'front': front,
        'back': back,
        'image': image,
        'box': box,
        'due': due,
        'created': created,
      };

  factory Flashcard.fromJson(Map<String, dynamic> j) => Flashcard(
        id: j['id'] as String,
        front: j['front'] as String,
        back: j['back'] as String,
        image: j['image'] as String?,
        box: (j['box'] ?? 0) as int,
        due: (j['due'] ?? 0) as int,
        created: j['created'] as int?,
      );
}

class ChatMsg {
  ChatMsg(this.role, this.text);
  final String role; // user | assistant
  final String text;
  bool get isUser => role == 'user';

  Map<String, dynamic> toJson() => {'role': role, 'text': text};
  factory ChatMsg.fromJson(Map<String, dynamic> j) =>
      ChatMsg(j['role'] as String, j['text'] as String);
}

class Settings {
  String provider = 'openai';
  String baseUrl = 'https://api.openai.com/v1';
  String model = 'gpt-4o-mini';
  String apiKey = '';
  String ttsEngine = 'device'; // device | google | openai
  String ttsLang = 'en-US';
  double ttsRate = 0.45;
  bool notifOn = true;
  int notifH = 20;
  int notifM = 0;
  int workMin = 25;
  int breakMin = 5;
  String theme = 'system'; // system | light | dark

  Map<String, dynamic> toJson() => {
        'provider': provider,
        'baseUrl': baseUrl,
        'model': model,
        'apiKey': apiKey,
        'ttsEngine': ttsEngine,
        'ttsLang': ttsLang,
        'ttsRate': ttsRate,
        'notifOn': notifOn,
        'notifH': notifH,
        'notifM': notifM,
        'workMin': workMin,
        'breakMin': breakMin,
        'theme': theme,
      };

  void load(Map<String, dynamic> j) {
    provider = (j['provider'] ?? provider) as String;
    baseUrl = (j['baseUrl'] ?? baseUrl) as String;
    model = (j['model'] ?? model) as String;
    apiKey = (j['apiKey'] ?? apiKey) as String;
    ttsEngine = (j['ttsEngine'] ?? ttsEngine) as String;
    ttsLang = (j['ttsLang'] ?? ttsLang) as String;
    ttsRate = ((j['ttsRate'] ?? ttsRate) as num).toDouble();
    notifOn = (j['notifOn'] ?? notifOn) as bool;
    notifH = (j['notifH'] ?? notifH) as int;
    notifM = (j['notifM'] ?? notifM) as int;
    workMin = (j['workMin'] ?? workMin) as int;
    breakMin = (j['breakMin'] ?? breakMin) as int;
    theme = (j['theme'] ?? theme) as String;
  }
}

class Pomo {
  String phase = 'idle'; // idle | work | break
  int startMs = 0;
  int endMs = 0;
  int grown = 0;
  int wilted = 0;
  String last = ''; // work | break | wilt | ''
  double lastGrowth = 0;

  Map<String, dynamic> toJson() => {
        'phase': phase,
        'startMs': startMs,
        'endMs': endMs,
        'grown': grown,
        'wilted': wilted,
        'last': last,
        'lastGrowth': lastGrowth,
      };

  void load(Map<String, dynamic> j) {
    phase = (j['phase'] ?? 'idle') as String;
    startMs = (j['startMs'] ?? 0) as int;
    endMs = (j['endMs'] ?? 0) as int;
    grown = (j['grown'] ?? 0) as int;
    wilted = (j['wilted'] ?? 0) as int;
    last = (j['last'] ?? '') as String;
    lastGrowth = ((j['lastGrowth'] ?? 0) as num).toDouble();
  }
}

class QuizQ {
  QuizQ(this.q, this.options, this.answer, this.explain);
  final String q;
  final List<String> options;
  final int answer;
  final String explain;
}
