import 'package:flutter/material.dart';

/// لوحة الألوان: أبيض + بني فاتح (فاتح) / أسود + أبيض (داكن)
class Pal {
  const Pal({
    required this.bg,
    required this.surface,
    required this.accent,
    required this.onAccent,
    required this.soft,
    required this.text,
    required this.line,
    required this.muted,
  });

  final Color bg, surface, accent, onAccent, soft, text, line, muted;

  static const light = Pal(
    bg: Color(0xFFFFFDF9),
    surface: Colors.white,
    accent: Color(0xFFC8A27A),
    onAccent: Color(0xFF2B2018),
    soft: Color(0xFFF5ECDF),
    text: Color(0xFF4A3626),
    line: Color(0xFF2B2018),
    muted: Color(0xFF8C7662),
  );

  static const dark = Pal(
    bg: Color(0xFF0D0D0D),
    surface: Color(0xFF181818),
    accent: Colors.white,
    onAccent: Colors.black,
    soft: Color(0xFF262626),
    text: Colors.white,
    line: Colors.white,
    muted: Color(0xFFA0A0A0),
  );

  static Pal of(BuildContext c) =>
      Theme.of(c).brightness == Brightness.dark ? dark : light;
}

OutlineInputBorder _border(Color c, double w) => OutlineInputBorder(
      borderRadius: BorderRadius.circular(16),
      borderSide: BorderSide(color: c, width: w),
    );

ThemeData buildTheme(Brightness b) {
  final p = b == Brightness.dark ? Pal.dark : Pal.light;
  final scheme = ColorScheme(
    brightness: b,
    primary: p.accent,
    onPrimary: p.onAccent,
    secondary: p.soft,
    onSecondary: p.text,
    error: const Color(0xFFC0392B),
    onError: Colors.white,
    surface: p.surface,
    onSurface: p.text,
  );
  return ThemeData(
    useMaterial3: true,
    brightness: b,
    colorScheme: scheme,
    scaffoldBackgroundColor: p.bg,
    textTheme: ThemeData(brightness: b)
        .textTheme
        .apply(bodyColor: p.text, displayColor: p.text),
    appBarTheme: AppBarTheme(
      backgroundColor: p.bg,
      foregroundColor: p.text,
      elevation: 0,
      scrolledUnderElevation: 0,
      centerTitle: true,
      titleTextStyle: TextStyle(
          color: p.text, fontSize: 20, fontWeight: FontWeight.w800),
    ),
    inputDecorationTheme: InputDecorationTheme(
      filled: true,
      fillColor: p.surface,
      hintStyle: TextStyle(color: p.muted),
      contentPadding:
          const EdgeInsets.symmetric(horizontal: 16, vertical: 14),
      border: _border(p.line, 2),
      enabledBorder: _border(p.line, 2),
      focusedBorder: _border(p.accent, 3),
    ),
    filledButtonTheme: FilledButtonThemeData(
      style: FilledButton.styleFrom(
        backgroundColor: p.accent,
        foregroundColor: p.onAccent,
        minimumSize: const Size(48, 52),
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(16),
          side: BorderSide(color: p.line, width: 2),
        ),
        textStyle:
            const TextStyle(fontWeight: FontWeight.w800, fontSize: 16),
      ),
    ),
    outlinedButtonTheme: OutlinedButtonThemeData(
      style: OutlinedButton.styleFrom(
        foregroundColor: p.text,
        minimumSize: const Size(48, 52),
        side: BorderSide(color: p.line, width: 2),
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
        textStyle:
            const TextStyle(fontWeight: FontWeight.w700, fontSize: 15),
      ),
    ),
    snackBarTheme: SnackBarThemeData(
      backgroundColor: p.line,
      contentTextStyle: TextStyle(color: p.bg, fontWeight: FontWeight.w600),
      behavior: SnackBarBehavior.floating,
    ),
  );
}
