import 'dart:io';
import 'dart:math';

import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:provider/provider.dart';

import '../art/character.dart';
import '../models.dart';
import '../services/ai.dart';
import '../services/media.dart';
import '../services/tts.dart';
import '../store.dart';
import '../theme.dart';
import '../widgets.dart';
import 'chat.dart';

// ───────────────────────── تلخيص من صورة ─────────────────────────

class SummarizeScreen extends StatefulWidget {
  const SummarizeScreen({super.key});
  @override
  State<SummarizeScreen> createState() => _SummarizeScreenState();
}

class _SummarizeScreenState extends State<SummarizeScreen> {
  String? _img;
  String _out = '';
  bool _busy = false;

  Future<void> _pick() async {
    final path = await chooseImage(context, maxWidth: 1600);
    if (path != null && mounted) setState(() => _img = path);
  }

  Future<void> _run() async {
    final app = context.read<AppState>();
    if (_img == null) return;
    setState(() {
      _busy = true;
      _out = '';
    });
    try {
      final bytes = await File(_img!).readAsBytes();
      final r = await app.ai.summarizeImage(bytes);
      if (mounted) setState(() => _out = r);
    } catch (e) {
      if (mounted) toast(context, '$e');
    } finally {
      if (mounted) setState(() => _busy = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    final p = Pal.of(context);
    final ready = context.watch<AppState>().ai.ready;
    return Scaffold(
      appBar: AppBar(title: const Text('تلخيص من صورة')),
      body: ListView(
        padding: const EdgeInsets.all(20),
        children: [
          if (!ready) const NeedKey(),
          if (!ready) const SizedBox(height: 12),
          SoftCard(
            onTap: _pick,
            padding: const EdgeInsets.all(12),
            child: _img == null
                ? SizedBox(
                    height: 150,
                    child: Column(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: [
                        Icon(Icons.add_a_photo_outlined, size: 40, color: p.muted),
                        const SizedBox(height: 8),
                        Text('اضغط لالتقاط أو اختيار صورة',
                            style: TextStyle(color: p.muted)),
                      ],
                    ),
                  )
                : CardImage(_img!, height: 220),
          ),
          const SizedBox(height: 14),
          FilledButton.icon(
            onPressed: (_img == null || _busy || !ready) ? null : _run,
            icon: _busy
                ? const SizedBox(
                    width: 18,
                    height: 18,
                    child: CircularProgressIndicator(strokeWidth: 2))
                : const Icon(Icons.auto_awesome_rounded),
            label: Text(_busy ? 'جارٍ التلخيص...' : 'لخّص'),
          ),
          if (_out.isNotEmpty) ...[
            const SizedBox(height: 16),
            SoftCard(
              child: SelectableText(_out,
                  textDirection: dirOf(_out),
                  style: const TextStyle(fontSize: 16, height: 1.55)),
            ),
            const SizedBox(height: 12),
            Row(
              children: [
                Expanded(
                  child: OutlinedButton.icon(
                    onPressed: () {
                      Clipboard.setData(ClipboardData(text: _out));
                      toast(context, 'تم النسخ');
                    },
                    icon: const Icon(Icons.copy_rounded),
                    label: const Text('نسخ'),
                  ),
                ),
                const SizedBox(width: 10),
                Expanded(
                  child: FilledButton.icon(
                    onPressed: () => Navigator.of(context).push(MaterialPageRoute(
                        builder: (_) => QuizScreen(source: _out))),
                    icon: const Icon(Icons.quiz_outlined),
                    label: const Text('اختبرني'),
                  ),
                ),
              ],
            ),
          ],
        ],
      ),
    );
  }
}

// ───────────────────────── الاختبارات ─────────────────────────

class QuizScreen extends StatefulWidget {
  const QuizScreen({super.key, this.source = ''});
  final String source;
  @override
  State<QuizScreen> createState() => _QuizScreenState();
}

class _QuizScreenState extends State<QuizScreen> {
  late final TextEditingController _src =
      TextEditingController(text: widget.source);
  List<QuizQ> _qs = [];
  int _i = 0;
  int _score = 0;
  int? _picked;
  int _count = 5;
  bool _busy = false;

  @override
  void dispose() {
    _src.dispose();
    super.dispose();
  }

  void _start(List<QuizQ> qs) => setState(() {
        _qs = qs;
        _i = 0;
        _score = 0;
        _picked = null;
      });

  Future<void> _fromAi() async {
    final app = context.read<AppState>();
    if (_src.text.trim().length < 20) {
      toast(context, 'الصق نصاً أطول لإنشاء الأسئلة');
      return;
    }
    setState(() => _busy = true);
    try {
      _start(await app.ai.makeQuiz(_src.text.trim(), _count));
    } catch (e) {
      if (mounted) toast(context, '$e');
    } finally {
      if (mounted) setState(() => _busy = false);
    }
  }

  void _fromCards() {
    final cards = List<Flashcard>.from(context.read<AppState>().cards);
    if (cards.length < 4) {
      toast(context, 'تحتاج 4 بطاقات على الأقل');
      return;
    }
    final r = Random();
    cards.shuffle(r);
    final picked = cards.take(min(_count, cards.length)).toList();
    final qs = picked.map((c) {
      final others = cards.where((o) => o.id != c.id && o.back != c.back).toList()
        ..shuffle(r);
      final opts = <String>{c.back, ...others.take(3).map((o) => o.back)}.toList()
        ..shuffle(r);
      return QuizQ('ما معنى «${c.front}»؟', opts, opts.indexOf(c.back), '');
    }).toList();
    _start(qs);
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('الاختبارات')),
      body: AnimatedSwitcher(
        duration: const Duration(milliseconds: 280),
        child: _qs.isEmpty
            ? KeyedSubtree(key: const ValueKey('setup'), child: _setup())
            : _i >= _qs.length
                ? KeyedSubtree(key: const ValueKey('end'), child: _result())
                : KeyedSubtree(key: ValueKey('q$_i'), child: _question()),
      ),
    );
  }

  Widget _setup() {
    final ready = context.watch<AppState>().ai.ready;
    return ListView(
      padding: const EdgeInsets.all(20),
      children: [
        const Center(child: Character(pose: Pose.book, height: 150)),
        const SizedBox(height: 8),
        Wrap(
          spacing: 8,
          children: [
            for (final n in [5, 10, 15])
              ChoiceChip(
                label: Text('$n أسئلة'),
                selected: _count == n,
                showCheckmark: false,
                selectedColor: Pal.of(context).accent,
                onSelected: (_) => setState(() => _count = n),
              ),
          ],
        ),
        const SizedBox(height: 14),
        FilledButton.icon(
          onPressed: _fromCards,
          icon: const Icon(Icons.style_rounded),
          label: const Text('من كلماتي (بدون إنترنت)'),
        ),
        const SizedBox(height: 22),
        TextField(
          controller: _src,
          minLines: 5,
          maxLines: 9,
          decoration: const InputDecoration(
              hintText: 'أو الصق نصاً/ملخصاً لإنشاء اختبار منه...'),
        ),
        const SizedBox(height: 10),
        if (!ready) const NeedKey(),
        if (ready)
          OutlinedButton.icon(
            onPressed: _busy ? null : _fromAi,
            icon: _busy
                ? const SizedBox(
                    width: 18,
                    height: 18,
                    child: CircularProgressIndicator(strokeWidth: 2))
                : const Icon(Icons.auto_awesome_rounded),
            label: Text(_busy ? 'جارٍ الإنشاء...' : 'أنشئ اختباراً من النص'),
          ),
      ],
    );
  }

  Widget _question() {
    final p = Pal.of(context);
    final q = _qs[_i];
    return ListView(
      padding: const EdgeInsets.all(20),
      children: [
        LinearProgressIndicator(
          value: _i / _qs.length,
          minHeight: 10,
          color: p.accent,
          backgroundColor: p.soft,
          borderRadius: BorderRadius.circular(8),
        ),
        const SizedBox(height: 6),
        Text('السؤال ${_i + 1} من ${_qs.length}',
            style: TextStyle(color: p.muted, fontSize: 13)),
        const SizedBox(height: 14),
        SoftCard(
          child: Text(q.q,
              textDirection: dirOf(q.q),
              style: const TextStyle(fontSize: 21, fontWeight: FontWeight.w800)),
        ),
        const SizedBox(height: 14),
        for (var k = 0; k < q.options.length; k++)
          Padding(
            padding: const EdgeInsets.only(bottom: 10),
            child: SoftCard(
              shadow: false,
              color: _picked == null
                  ? null
                  : k == q.answer
                      ? const Color(0xFF7BA05B).withAlpha(120)
                      : k == _picked
                          ? const Color(0xFFC0392B).withAlpha(110)
                          : null,
              onTap: _picked != null
                  ? null
                  : () => setState(() {
                        _picked = k;
                        if (k == q.answer) _score++;
                      }),
              child: Text(q.options[k],
                  textDirection: dirOf(q.options[k]),
                  style: const TextStyle(fontSize: 17, fontWeight: FontWeight.w600)),
            ),
          ),
        if (_picked != null) ...[
          if (q.explain.isNotEmpty)
            Padding(
              padding: const EdgeInsets.only(bottom: 10),
              child: Text(q.explain,
                  textDirection: dirOf(q.explain),
                  style: TextStyle(color: p.muted, height: 1.4)),
            ),
          FilledButton(
            onPressed: () => setState(() {
              _i++;
              _picked = null;
            }),
            child: Text(_i + 1 == _qs.length ? 'النتيجة' : 'التالي'),
          ),
        ],
      ],
    );
  }

  Widget _result() {
    final p = Pal.of(context);
    final ratio = _score / _qs.length;
    final msg = ratio >= 0.8
        ? 'ممتاز! 🌟'
        : ratio >= 0.5
            ? 'جيد، كرّر المحاولة'
            : 'لا بأس، المراجعة تصنع الفرق';
    return ListView(
      padding: const EdgeInsets.all(20),
      children: [
        const Center(child: Character(pose: Pose.cards, height: 190)),
        Center(
          child: TweenAnimationBuilder<double>(
            tween: Tween(begin: 0, end: _score.toDouble()),
            duration: const Duration(milliseconds: 900),
            builder: (c, v, _) => Text('${v.round()} / ${_qs.length}',
                style: const TextStyle(fontSize: 46, fontWeight: FontWeight.w900)),
          ),
        ),
        Center(child: Text(msg, style: TextStyle(color: p.muted, fontSize: 16))),
        const SizedBox(height: 20),
        FilledButton(
            onPressed: () => setState(() {
                  _qs = [];
                }),
            child: const Text('اختبار جديد')),
      ],
    );
  }
}

// ───────────────────────── فاينمان ─────────────────────────

class FeynmanScreen extends StatefulWidget {
  const FeynmanScreen({super.key});
  @override
  State<FeynmanScreen> createState() => _FeynmanScreenState();
}

class _FeynmanScreenState extends State<FeynmanScreen> {
  final _topic = TextEditingController();
  final List<ChatMsg> _msgs = [];
  bool _started = false;
  bool _busy = false;

  @override
  void dispose() {
    _topic.dispose();
    super.dispose();
  }

  void _begin() {
    final t = _topic.text.trim();
    if (t.isEmpty) return;
    setState(() {
      _started = true;
      _msgs
        ..clear()
        ..add(ChatMsg('assistant',
            'تمام! اشرح لي «$t» كأنك تشرحه لطفل عمره 12 سنة. استخدم كلماتك أنت، وبعدها سأخبرك أين الثغرات.'));
    });
  }

  Future<void> _send(String text) async {
    final app = context.read<AppState>();
    if (!app.ai.ready) {
      toast(context, 'أضف مفتاح API من الإعدادات أولاً');
      return;
    }
    setState(() {
      _msgs.add(ChatMsg('user', text));
      _busy = true;
    });
    try {
      final hist = [
        ChatMsg('user', 'الموضوع: ${_topic.text.trim()}'),
        ..._msgs.where((m) => !(m.role == 'assistant' && _msgs.indexOf(m) == 0)),
      ];
      final r = await app.ai.ask(history: hist, system: AiService.feynmanSystem);
      if (mounted) setState(() => _msgs.add(ChatMsg('assistant', r)));
    } catch (e) {
      if (mounted) toast(context, '$e');
    } finally {
      if (mounted) setState(() => _busy = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    final ready = context.watch<AppState>().ai.ready;
    return Scaffold(
      appBar: AppBar(title: const Text('طريقة فاينمان')),
      body: !_started
          ? ListView(
              padding: const EdgeInsets.all(20),
              children: [
                const Center(child: Character(pose: Pose.chat, height: 170)),
                const SizedBox(height: 8),
                const Text(
                  'اختر موضوعاً تريد إتقانه، ثم اشرحه بكلماتك البسيطة. '
                  'سيكشف لك الذكاء الاصطناعي الثغرات ويسألك أسئلة تبسيط.',
                  textAlign: TextAlign.center,
                ),
                const SizedBox(height: 16),
                TextField(
                  controller: _topic,
                  decoration: const InputDecoration(
                      hintText: 'الموضوع (مثل: التمثيل الضوئي)'),
                ),
                const SizedBox(height: 12),
                if (!ready) const NeedKey(),
                if (ready)
                  FilledButton(onPressed: _begin, child: const Text('ابدأ الشرح')),
              ],
            )
          : ChatPane(
              messages: _msgs,
              busy: _busy,
              onSend: _send,
              hint: 'اشرح بكلماتك...',
            ),
    );
  }
}

// ───────────────────────── مراجعة البطاقات ─────────────────────────

class ReviewScreen extends StatefulWidget {
  const ReviewScreen({super.key});
  @override
  State<ReviewScreen> createState() => _ReviewScreenState();
}

class _ReviewScreenState extends State<ReviewScreen> {
  late List<Flashcard> _queue;
  int _total = 0;
  int _known = 0;
  bool _flip = false;
  bool _all = false;

  @override
  void initState() {
    super.initState();
    _queue = context.read<AppState>().dueCards();
    _total = _queue.length;
  }

  void _reviewAll() {
    final l = List<Flashcard>.from(context.read<AppState>().cards)..shuffle();
    setState(() {
      _queue = l;
      _total = l.length;
      _known = 0;
      _all = true;
      _flip = false;
    });
  }

  void _answer(bool known) {
    final app = context.read<AppState>();
    final c = _queue.first;
    app.review(c, known);
    setState(() {
      _queue.removeAt(0);
      if (known) {
        _known++;
      } else {
        _queue.add(c);
      }
      _flip = false;
    });
  }

  @override
  Widget build(BuildContext context) {
    final p = Pal.of(context);
    final app = context.watch<AppState>();
    Widget body;
    if (app.cards.isEmpty) {
      body = _msg('لا توجد بطاقات بعد. أنشئ بعضها أولاً!', Pose.cards, null);
    } else if (_queue.isEmpty && _total == 0) {
      body = _msg('لا توجد بطاقات مستحقة الآن 🎉', Pose.book,
          FilledButton(onPressed: _reviewAll, child: const Text('راجع الكل على أي حال')));
    } else if (_queue.isEmpty) {
      body = _msg('أنهيت المراجعة! عرفت $_known من $_total', Pose.cards,
          _all ? null : FilledButton(onPressed: _reviewAll, child: const Text('راجع الكل')));
    } else {
      final c = _queue.first;
      body = ListView(
        padding: const EdgeInsets.all(20),
        children: [
          LinearProgressIndicator(
            value: _total == 0 ? 0 : _known / _total,
            minHeight: 10,
            color: p.accent,
            backgroundColor: p.soft,
            borderRadius: BorderRadius.circular(8),
          ),
          const SizedBox(height: 6),
          Text('المتبقي: ${_queue.length}',
              style: TextStyle(color: p.muted, fontSize: 13)),
          const SizedBox(height: 14),
          FlipCard(
            front: c.front,
            back: c.back,
            image: c.image,
            flipped: _flip,
            onTap: () => setState(() => _flip = !_flip),
            height: 300,
          ),
          const SizedBox(height: 10),
          Center(
            child: IconButton.filled(
              onPressed: () =>
                  Tts.i.speak(c.front, app.settings).catchError((_) {}),
              icon: const Icon(Icons.volume_up_rounded),
            ),
          ),
          const SizedBox(height: 10),
          Row(
            children: [
              Expanded(
                child: OutlinedButton.icon(
                  onPressed: () => _answer(false),
                  icon: const Icon(Icons.close_rounded),
                  label: const Text('لم أعرفها'),
                ),
              ),
              const SizedBox(width: 10),
              Expanded(
                child: FilledButton.icon(
                  onPressed: () => _answer(true),
                  icon: const Icon(Icons.check_rounded),
                  label: const Text('عرفتها'),
                ),
              ),
            ],
          ),
        ],
      );
    }
    return Scaffold(
      appBar: AppBar(title: const Text('مراجعة البطاقات')),
      body: body,
    );
  }

  Widget _msg(String t, Pose pose, Widget? action) {
    return Center(
      child: Padding(
        padding: const EdgeInsets.all(24),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Character(pose: pose, height: 180),
            const SizedBox(height: 10),
            Text(t,
                textAlign: TextAlign.center,
                style: const TextStyle(fontSize: 18, fontWeight: FontWeight.w700)),
            if (action != null) ...[const SizedBox(height: 16), action],
          ],
        ),
      ),
    );
  }
}
