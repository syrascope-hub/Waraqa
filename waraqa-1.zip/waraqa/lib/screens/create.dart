import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../art/character.dart';
import '../services/media.dart';
import '../store.dart';
import '../theme.dart';
import '../widgets.dart';

class _Draft {
  _Draft(this.front, this.back, this.image);
  final String front;
  final String back;
  final String? image;
}

List<List<String>> parsePairs(String text) {
  final out = <List<String>>[];
  final re = RegExp(r'^(.*?)[,،\t;]\s*(.+)$');
  for (final raw in text.split('\n')) {
    final line = raw.trim();
    if (line.isEmpty) continue;
    final m = re.firstMatch(line);
    if (m != null && m.group(1)!.trim().isNotEmpty) {
      out.add([m.group(1)!.trim(), m.group(2)!.trim()]);
    } else {
      out.add([line, '']);
    }
  }
  return out;
}

class CreateTab extends StatefulWidget {
  const CreateTab({super.key});
  @override
  State<CreateTab> createState() => _CreateTabState();
}

class _CreateTabState extends State<CreateTab> {
  bool _bulkMode = false;

  // يدوي
  final _front = TextEditingController();
  final _back = TextEditingController();
  String? _img;
  bool _flipped = false;

  // من نص
  final _bulk = TextEditingController();
  final Map<String, String> _imgs = {};
  final Map<String, String> _tr = {};
  final Set<String> _skip = {};
  bool _busy = false;

  @override
  void dispose() {
    _front.dispose();
    _back.dispose();
    _bulk.dispose();
    super.dispose();
  }

  Future<void> _pickManual() async {
    final path = await chooseImage(context);
    if (path != null && mounted) setState(() => _img = path);
  }

  void _saveManual() {
    final f = _front.text.trim();
    final b = _back.text.trim();
    if (f.isEmpty || b.isEmpty) {
      toast(context, 'اكتب الكلمة وترجمتها أولاً');
      return;
    }
    context.read<AppState>().addCard(f, b, _img);
    setState(() {
      _front.clear();
      _back.clear();
      _img = null;
      _flipped = false;
    });
    toast(context, 'تمت إضافة البطاقة ✓');
  }

  List<_Draft> get _drafts {
    final out = <_Draft>[];
    for (final pr in parsePairs(_bulk.text)) {
      if (_skip.contains(pr[0])) continue;
      final back = pr[1].isNotEmpty ? pr[1] : (_tr[pr[0]] ?? '');
      out.add(_Draft(pr[0], back, _imgs[pr[0]]));
    }
    return out;
  }

  Future<void> _translateMissing() async {
    final app = context.read<AppState>();
    final missing =
        _drafts.where((d) => d.back.isEmpty).map((d) => d.front).toList();
    if (missing.isEmpty) return;
    setState(() => _busy = true);
    try {
      final m = await app.ai.translate(missing);
      if (!mounted) return;
      setState(() => _tr.addAll(m));
    } catch (e) {
      if (mounted) toast(context, '$e');
    } finally {
      if (mounted) setState(() => _busy = false);
    }
  }

  Future<void> _pickFor(String front) async {
    final path = await chooseImage(context);
    if (path != null && mounted) setState(() => _imgs[front] = path);
  }

  void _createAll() {
    final app = context.read<AppState>();
    final ready = _drafts.where((d) => d.back.isNotEmpty).toList();
    if (ready.isEmpty) {
      toast(context, 'لا توجد أزواج صالحة (كلمة, ترجمة)');
      return;
    }
    app.addMany(
        ready.map((d) => app.make(d.front, d.back, d.image)).toList());
    setState(() {
      _bulk.clear();
      _imgs.clear();
      _tr.clear();
      _skip.clear();
    });
    toast(context, 'تم إنشاء ${ready.length} بطاقة ✓');
  }

  @override
  Widget build(BuildContext context) {
    final p = Pal.of(context);
    return ListView(
      padding: const EdgeInsets.fromLTRB(20, 12, 20, 24),
      children: [
        const Pop(
            child: TabHeader(title: 'إنشاء بطاقات', subtitle: 'كلمة وترجمتها وصورة')),
        const SizedBox(height: 12),
        Pop(
          index: 1,
          child: SegmentedButton<bool>(
            segments: const [
              ButtonSegment(
                  value: false,
                  icon: Icon(Icons.edit_outlined),
                  label: Text('يدوي')),
              ButtonSegment(
                  value: true,
                  icon: Icon(Icons.notes_rounded),
                  label: Text('من نص')),
            ],
            selected: {_bulkMode},
            showSelectedIcon: false,
            onSelectionChanged: (s) => setState(() => _bulkMode = s.first),
          ),
        ),
        const SizedBox(height: 16),
        AnimatedSwitcher(
          duration: const Duration(milliseconds: 250),
          child: _bulkMode
              ? KeyedSubtree(key: const ValueKey('b'), child: _bulkUi(p))
              : KeyedSubtree(key: const ValueKey('m'), child: _manualUi(p)),
        ),
      ],
    );
  }

  Widget _manualUi(Pal p) {
    final f = _front.text.trim().isEmpty ? 'الكلمة' : _front.text.trim();
    final b = _back.text.trim().isEmpty ? 'الترجمة' : _back.text.trim();
    return Column(
      crossAxisAlignment: CrossAxisAlignment.stretch,
      children: [
        Row(
          crossAxisAlignment: CrossAxisAlignment.end,
          children: [
            Expanded(
              child: FlipCard(
                front: f,
                back: b,
                image: _img,
                flipped: _flipped,
                onTap: () => setState(() => _flipped = !_flipped),
                height: 230,
              ),
            ),
            const SizedBox(width: 8),
            const Character(pose: Pose.phone, height: 150),
          ],
        ),
        const SizedBox(height: 16),
        TextField(
          controller: _front,
          textDirection: dirOf(_front.text),
          decoration: const InputDecoration(hintText: 'الكلمة (مثل: apple)'),
          onChanged: (_) => setState(() {}),
        ),
        const SizedBox(height: 10),
        TextField(
          controller: _back,
          textDirection: dirOf(_back.text),
          decoration: const InputDecoration(hintText: 'الترجمة (مثل: تفاحة)'),
          onChanged: (_) => setState(() {}),
        ),
        const SizedBox(height: 10),
        Row(
          children: [
            Expanded(
              child: OutlinedButton.icon(
                onPressed: _pickManual,
                icon: const Icon(Icons.add_photo_alternate_outlined),
                label: Text(_img == null ? 'إضافة صورة' : 'تغيير الصورة'),
              ),
            ),
            if (_img != null) ...[
              const SizedBox(width: 8),
              IconButton(
                onPressed: () => setState(() => _img = null),
                icon: const Icon(Icons.close_rounded),
              ),
            ],
          ],
        ),
        const SizedBox(height: 10),
        FilledButton.icon(
          onPressed: _saveManual,
          icon: const Icon(Icons.check_rounded),
          label: const Text('حفظ البطاقة'),
        ),
      ],
    );
  }

  Widget _bulkUi(Pal p) {
    final drafts = _drafts;
    final missing = drafts.any((d) => d.back.isEmpty);
    return Column(
      crossAxisAlignment: CrossAxisAlignment.stretch,
      children: [
        TextField(
          controller: _bulk,
          minLines: 5,
          maxLines: 9,
          decoration: const InputDecoration(
            hintText: 'سطر لكل بطاقة، الكلمة ثم فاصلة ثم الترجمة:\n'
                'apple, تفاحة\nbook, كتاب',
          ),
          onChanged: (_) => setState(() {}),
        ),
        const SizedBox(height: 12),
        if (drafts.isEmpty)
          Padding(
            padding: const EdgeInsets.symmetric(vertical: 8),
            child: Column(
              children: [
                const Character(pose: Pose.cards, height: 150),
                Text('الصق قائمة كلماتك وستظهر هنا للمعاينة',
                    style: TextStyle(color: p.muted)),
              ],
            ),
          ),
        for (final d in drafts)
          Padding(
            padding: const EdgeInsets.only(bottom: 8),
            child: SoftCard(
              padding: const EdgeInsets.all(8),
              shadow: false,
              child: Row(
                children: [
                  InkWell(
                    onTap: () => _pickFor(d.front),
                    borderRadius: BorderRadius.circular(12),
                    child: SizedBox(
                      width: 52,
                      height: 52,
                      child: d.image != null
                          ? CardImage(d.image!, height: 52)
                          : Icon(Icons.add_photo_alternate_outlined,
                              color: p.muted),
                    ),
                  ),
                  const SizedBox(width: 10),
                  Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(d.front,
                            textDirection: dirOf(d.front),
                            style: const TextStyle(
                                fontWeight: FontWeight.w800, fontSize: 16)),
                        Text(d.back.isEmpty ? '(بدون ترجمة)' : d.back,
                            textDirection: dirOf(d.back),
                            style: TextStyle(color: p.muted)),
                      ],
                    ),
                  ),
                  IconButton(
                    onPressed: () => setState(() => _skip.add(d.front)),
                    icon: const Icon(Icons.close_rounded),
                  ),
                ],
              ),
            ),
          ),
        if (missing)
          OutlinedButton.icon(
            onPressed: _busy ? null : _translateMissing,
            icon: _busy
                ? const SizedBox(
                    width: 18,
                    height: 18,
                    child: CircularProgressIndicator(strokeWidth: 2))
                : const Icon(Icons.translate_rounded),
            label: const Text('ترجمة الناقص بالذكاء الاصطناعي'),
          ),
        if (missing) const SizedBox(height: 10),
        FilledButton.icon(
          onPressed: drafts.isEmpty ? null : _createAll,
          icon: const Icon(Icons.library_add_check_rounded),
          label: Text(drafts.isEmpty
              ? 'إنشاء البطاقات'
              : 'إنشاء ${drafts.where((d) => d.back.isNotEmpty).length} بطاقة'),
        ),
      ],
    );
  }
}
