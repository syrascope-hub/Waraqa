import 'package:flutter/material.dart';

import '../art/character.dart';
import '../widgets.dart';
import 'study_tools.dart';

class StudyTab extends StatelessWidget {
  const StudyTab({super.key});

  void _go(BuildContext c, Widget w) =>
      Navigator.of(c).push(MaterialPageRoute(builder: (_) => w));

  @override
  Widget build(BuildContext context) {
    return ListView(
      padding: const EdgeInsets.fromLTRB(20, 12, 20, 24),
      children: [
        const Pop(child: TabHeader(title: 'دراسة', subtitle: 'أدوات ذكية للمذاكرة')),
        const SizedBox(height: 4),
        const Center(child: Character(pose: Pose.book, height: 180)),
        const SizedBox(height: 8),
        Pop(
          index: 1,
          child: ToolCard(
            icon: Icons.document_scanner_outlined,
            title: 'تلخيص من صورة',
            desc: 'صوّر صفحة أو لوحة واحصل على ملخص منظم',
            onTap: () => _go(context, const SummarizeScreen()),
          ),
        ),
        const SizedBox(height: 12),
        Pop(
          index: 2,
          child: ToolCard(
            icon: Icons.quiz_outlined,
            title: 'اختبارات',
            desc: 'من كلماتك بدون إنترنت أو من أي نص بالذكاء الاصطناعي',
            onTap: () => _go(context, const QuizScreen()),
          ),
        ),
        const SizedBox(height: 12),
        Pop(
          index: 3,
          child: ToolCard(
            icon: Icons.psychology_alt_outlined,
            title: 'طريقة فاينمان',
            desc: 'اشرح الموضوع بكلماتك ودع الذكاء الاصطناعي يكشف الثغرات',
            onTap: () => _go(context, const FeynmanScreen()),
          ),
        ),
        const SizedBox(height: 12),
        Pop(
          index: 4,
          child: ToolCard(
            icon: Icons.style_outlined,
            title: 'مراجعة البطاقات',
            desc: 'تكرار متباعد يذكّرك بالكلمات في الوقت المناسب',
            onTap: () => _go(context, const ReviewScreen()),
          ),
        ),
      ],
    );
  }
}
