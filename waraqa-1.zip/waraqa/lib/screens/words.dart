import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../art/character.dart';
import '../models.dart';
import '../services/tts.dart';
import '../store.dart';
import '../theme.dart';
import '../widgets.dart';

class WordsTab extends StatefulWidget {
  const WordsTab({super.key});
  @override
  State<WordsTab> createState() => _WordsTabState();
}

class _WordsTabState extends State<WordsTab> {
  String _q = '';

  Future<void> _speak(Flashcard c) async {
    final s = context.read<AppState>().settings;
    try {
      await Tts.i.speak(c.front, s);
    } catch (e) {
      if (mounted) toast(context, 'تعذّر النطق');
    }
  }

  Future<void> _edit(Flashcard c) async {
    final f = TextEditingController(text: c.front);
    final b = TextEditingController(text: c.back);
    final app = context.read<AppState>();
    final ok = await showDialog<bool>(
      context: context,
      builder: (d) => AlertDialog(
        title: const Text('تعديل البطاقة'),
        content: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            TextField(controller: f, decoration: const InputDecoration(hintText: 'الكلمة')),
            const SizedBox(height: 10),
            TextField(controller: b, decoration: const InputDecoration(hintText: 'الترجمة')),
          ],
        ),
        actions: [
          TextButton(onPressed: () => Navigator.pop(d, false), child: const Text('إلغاء')),
          FilledButton(onPressed: () => Navigator.pop(d, true), child: const Text('حفظ')),
        ],
      ),
    );
    if (ok == true && f.text.trim().isNotEmpty && b.text.trim().isNotEmpty) {
      app.updateCard(c, f.text.trim(), b.text.trim());
    }
  }

  Future<bool> _confirmDelete(Flashcard c) async {
    final ok = await showDialog<bool>(
      context: context,
      builder: (d) => AlertDialog(
        title: const Text('حذف البطاقة؟'),
        content: Text('«${c.front}» ستُحذف نهائياً.'),
        actions: [
          TextButton(onPressed: () => Navigator.pop(d, false), child: const Text('إلغاء')),
          FilledButton(onPressed: () => Navigator.pop(d, true), child: const Text('حذف')),
        ],
      ),
    );
    return ok == true;
  }

  @override
  Widget build(BuildContext context) {
    final p = Pal.of(context);
    final app = context.watch<AppState>();
    final q = _q.trim().toLowerCase();
    final list = app.cards
        .where((c) =>
            q.isEmpty || c.front.toLowerCase().contains(q) || c.back.contains(q))
        .toList()
      ..sort((a, b) => b.created.compareTo(a.created));

    return Padding(
      padding: const EdgeInsets.fromLTRB(20, 12, 20, 0),
      child: Column(
        children: [
          TabHeader(title: 'كلماتي', subtitle: '${app.cards.length} بطاقة'),
          const SizedBox(height: 10),
          TextField(
            onChanged: (v) => setState(() => _q = v),
            decoration: const InputDecoration(
              hintText: 'بحث...',
              prefixIcon: Icon(Icons.search_rounded),
            ),
          ),
          const SizedBox(height: 10),
          Expanded(
            child: list.isEmpty
                ? Center(
                    child: Column(
                      mainAxisSize: MainAxisSize.min,
                      children: [
                        const Character(pose: Pose.cards, height: 170),
                        const SizedBox(height: 8),
                        Text(
                            app.cards.isEmpty
                                ? 'لا توجد كلمات بعد، أنشئ أول بطاقة!'
                                : 'لا نتائج',
                            style: TextStyle(color: p.muted)),
                      ],
                    ),
                  )
                : ListView.builder(
                    padding: const EdgeInsets.only(bottom: 12, top: 4),
                    itemCount: list.length,
                    itemBuilder: (ctx, i) {
                      final c = list[i];
                      return Padding(
                        padding: const EdgeInsets.only(bottom: 10),
                        child: Dismissible(
                          key: ValueKey(c.id),
                          direction: DismissDirection.horizontal,
                          confirmDismiss: (_) => _confirmDelete(c),
                          onDismissed: (_) => app.deleteCard(c),
                          background: Container(
                            decoration: BoxDecoration(
                              color: const Color(0xFFC0392B),
                              borderRadius: BorderRadius.circular(22),
                            ),
                            alignment: Alignment.center,
                            child: const Icon(Icons.delete_outline_rounded,
                                color: Colors.white),
                          ),
                          child: SoftCard(
                            padding: const EdgeInsets.all(10),
                            onTap: () => _edit(c),
                            child: Row(
                              children: [
                                SizedBox(
                                  width: 54,
                                  height: 54,
                                  child: c.image != null
                                      ? CardImage(c.image!, height: 54)
                                      : Container(
                                          decoration: BoxDecoration(
                                            color: p.soft,
                                            borderRadius:
                                                BorderRadius.circular(14),
                                          ),
                                          alignment: Alignment.center,
                                          child: Text(
                                            c.front.isEmpty
                                                ? '?'
                                                : c.front
                                                    .substring(0, 1)
                                                    .toUpperCase(),
                                            style: const TextStyle(
                                                fontSize: 22,
                                                fontWeight: FontWeight.w900),
                                          ),
                                        ),
                                ),
                                const SizedBox(width: 12),
                                Expanded(
                                  child: Column(
                                    crossAxisAlignment:
                                        CrossAxisAlignment.start,
                                    children: [
                                      Text(c.front,
                                          textDirection: dirOf(c.front),
                                          style: const TextStyle(
                                              fontSize: 18,
                                              fontWeight: FontWeight.w800)),
                                      Text(c.back,
                                          textDirection: dirOf(c.back),
                                          style: TextStyle(color: p.muted)),
                                    ],
                                  ),
                                ),
                                IconButton.filled(
                                  onPressed: () => _speak(c),
                                  icon: const Icon(Icons.volume_up_rounded),
                                  tooltip: 'نطق',
                                ),
                              ],
                            ),
                          ),
                        ),
                      );
                    },
                  ),
          ),
        ],
      ),
    );
  }
}
