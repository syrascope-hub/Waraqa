"""يرسم أيقونة التطبيق: بطاقتان وورقة نبات (أبيض + بني فاتح + إطار داكن)."""
from PIL import Image, ImageDraw
import math

S = 1024
K = 2  # supersampling
INK = (43, 32, 24, 255)
BROWN = (200, 162, 122, 255)
CREAM = (255, 244, 220, 255)
WHITE = (255, 255, 255, 255)
GREEN = (123, 160, 91, 255)


def card(size, angle, fill):
    w, h = int(size * 0.50), int(size * 0.64)
    pad = 40
    im = Image.new("RGBA", (w + pad * 2, h + pad * 2), (0, 0, 0, 0))
    d = ImageDraw.Draw(im)
    r = int(size * 0.07)
    d.rounded_rectangle([pad, pad, pad + w, pad + h], r, fill=fill,
                        outline=INK, width=int(size * 0.025))
    return im.rotate(angle, resample=Image.BICUBIC, expand=True)


def leaf(size):
    im = Image.new("RGBA", (size, size), (0, 0, 0, 0))
    d = ImageDraw.Draw(im)
    pts = []
    for i in range(41):
        t = i / 40
        x = size * 0.5 + math.sin(math.pi * t) * size * 0.30
        y = size * 0.08 + t * size * 0.84
        pts.append((x, y))
    left = [(size - x, y) for x, y in reversed(pts)]
    poly = pts + left
    d.polygon(poly, fill=GREEN)
    d.line(poly + [poly[0]], fill=INK, width=int(size * 0.045), joint="curve")
    d.line([(size * 0.5, size * 0.12), (size * 0.5, size * 0.95)], fill=INK,
           width=int(size * 0.04))
    for k in range(1, 4):
        y = size * (0.25 + k * 0.17)
        d.line([(size * 0.5, y), (size * 0.5 + size * 0.17, y - size * 0.09)],
               fill=INK, width=int(size * 0.025))
        d.line([(size * 0.5, y), (size * 0.5 - size * 0.17, y - size * 0.09)],
               fill=INK, width=int(size * 0.025))
    return im


def compose(size, background):
    big = size * K
    base = Image.new("RGBA", (big, big), background)
    a = card(big, 10, CREAM)
    b = card(big, -9, WHITE)
    base.alpha_composite(a, (int(big * 0.5 - a.width / 2 + big * 0.07),
                             int(big * 0.5 - a.height / 2)))
    base.alpha_composite(b, (int(big * 0.5 - b.width / 2 - big * 0.05),
                             int(big * 0.5 - b.height / 2 + big * 0.01)))
    lf = leaf(int(big * 0.36))
    lf = lf.rotate(-12, resample=Image.BICUBIC, expand=True)
    base.alpha_composite(lf, (int(big * 0.5 - lf.width / 2 - big * 0.04),
                              int(big * 0.5 - lf.height / 2)))
    return base.resize((size, size), Image.LANCZOS)


if __name__ == "__main__":
    # الأيقونة الكاملة (خلفية بنية)
    compose(S, BROWN).convert("RGB").save("assets/icon.png", optimize=True)
    # طبقة أمامية شفافة للأيقونة التكيفية (محتوى داخل المنطقة الآمنة)
    fg = compose(S, (0, 0, 0, 0))
    canvas = Image.new("RGBA", (S, S), (0, 0, 0, 0))
    small = fg.resize((int(S * 0.66), int(S * 0.66)), Image.LANCZOS)
    canvas.alpha_composite(small, ((S - small.width) // 2, (S - small.height) // 2))
    canvas.save("assets/icon_fg.png", optimize=True)
    print("ok")
