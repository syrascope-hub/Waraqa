"""يعدّل مشروع android المولَّد بـ flutter create: الصلاحيات، مستقبلات الإشعارات،
اسم التطبيق، وdesugaring المطلوب لـ flutter_local_notifications."""
import pathlib
import re
import sys

root = pathlib.Path("android")
manifest = root / "app/src/main/AndroidManifest.xml"
if not manifest.exists():
    sys.exit("android/ folder not found - run flutter create first")

t = manifest.read_text(encoding="utf-8")

PERMS = """
    <uses-permission android:name="android.permission.INTERNET"/>
    <uses-permission android:name="android.permission.POST_NOTIFICATIONS"/>
    <uses-permission android:name="android.permission.VIBRATE"/>
    <uses-permission android:name="android.permission.RECEIVE_BOOT_COMPLETED"/>
    <uses-permission android:name="android.permission.USE_EXACT_ALARM"/>
    <uses-permission android:name="android.permission.SCHEDULE_EXACT_ALARM" android:maxSdkVersion="32"/>
    <queries>
        <intent>
            <action android:name="android.intent.action.TTS_SERVICE"/>
        </intent>
    </queries>
"""

RECEIVERS = """
        <receiver android:exported="false" android:name="com.dexterous.flutterlocalnotifications.ScheduledNotificationReceiver"/>
        <receiver android:exported="false" android:name="com.dexterous.flutterlocalnotifications.ScheduledNotificationBootReceiver">
            <intent-filter>
                <action android:name="android.intent.action.BOOT_COMPLETED"/>
                <action android:name="android.intent.action.MY_PACKAGE_REPLACED"/>
                <action android:name="android.intent.action.QUICKBOOT_POWERON"/>
                <action android:name="com.htc.intent.action.QUICKBOOT_POWERON"/>
            </intent-filter>
        </receiver>
"""

if "POST_NOTIFICATIONS" not in t:
    t = t.replace("<application", PERMS + "    <application", 1)
if "ScheduledNotificationReceiver" not in t:
    t = t.replace("</application>", RECEIVERS + "    </application>", 1)
t = re.sub(r'android:label="[^"]*"', 'android:label="ورقة"', t, count=1)
manifest.write_text(t, encoding="utf-8")

# ---- gradle: core library desugaring ----
app = root / "app"
kts = app / "build.gradle.kts"
groovy = app / "build.gradle"
if kts.exists():
    g = kts.read_text(encoding="utf-8")
    if "isCoreLibraryDesugaringEnabled" not in g:
        g = re.sub(r"compileOptions\s*\{",
                   "compileOptions {\n        isCoreLibraryDesugaringEnabled = true",
                   g, count=1)
        g += '\ndependencies {\n    coreLibraryDesugaring("com.android.tools:desugar_jdk_libs:2.1.5")\n}\n'
        kts.write_text(g, encoding="utf-8")
elif groovy.exists():
    g = groovy.read_text(encoding="utf-8")
    if "coreLibraryDesugaringEnabled" not in g:
        g = re.sub(r"compileOptions\s*\{",
                   "compileOptions {\n        coreLibraryDesugaringEnabled true",
                   g, count=1)
        g += "\ndependencies {\n    coreLibraryDesugaring 'com.android.tools:desugar_jdk_libs:2.1.5'\n}\n"
        groovy.write_text(g, encoding="utf-8")
else:
    sys.exit("no app/build.gradle(.kts) found")

print("android patched")
